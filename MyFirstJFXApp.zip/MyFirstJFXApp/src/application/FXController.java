package application;


import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

public class FXController {
	
	@FXML
	private Button start_btn;
	
	@FXML
	private ImageView currentFrame;
	
}
